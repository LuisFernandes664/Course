# Clone do instagram  :smile:

Neste Projeto foi realizado o clone da página de login do instagram, com flex box.

* HTML5;
* CSS3.