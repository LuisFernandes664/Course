# Clone Netflix :slightly_smiling_face:

Gostei muito de trabalhar neste Projeto, apesar das dificuldades Consegui terminar: :sweat_smile:

* Menu Funcional;
* Página de login pronta, não dá para cadastrar usuários... mas visualmente está pronta;
* Nos slides as series/filmes são todos clicáveis, e são redirecionados para os trailers respetivos a cada um.

# HTML, CSS :sparkles:



